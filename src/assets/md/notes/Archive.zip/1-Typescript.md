### Intro

```
TypeScript est la version ES6 de JavaScript et quelques autres 
fonctionnalités de TypeScript uniquement dont Angular a besoin
pour fonctionner.
```
* TypeScript est juste du JavaScript avec quelques fonctionnalités plus avancées. Le navigateur ne peut pas exécuter
* TypeScript, nous devons donc tout d'abord le transpiler en JavaScript. 
* La version la plus commune de JavaScript est actuellement ES5, nous avons donc transcrit TypeScript en JavaScript ES5.
