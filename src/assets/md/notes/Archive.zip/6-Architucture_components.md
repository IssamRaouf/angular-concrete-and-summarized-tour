### Intro

Découper une application en plusieurs composants logiques facilite 
les tâches suivantes:
* Architecte une application à mesure qu'elle gagne en complexité.

* Réutilisez des composants communs à plusieurs endroits.
